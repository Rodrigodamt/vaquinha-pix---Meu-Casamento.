# Vaquinha do Casamento

Obrigado por apoiar nosso sonho! 💍

## Como publicar esta página no GitHub Pages:

1. Acesse seu repositório no GitHub.
2. Clique em **Add file → Upload files**.
3. Faça upload dos arquivos:
   - index.html
   - foto.jpg
4. Clique em **Commit changes** para salvar.
5. Vá em **Settings → Pages**.
6. Em **Source**, selecione:
   - Branch: main
   - Folder: / (root)
7. Clique em **Save**.
8. Aguarde alguns segundos e copie o link gerado: